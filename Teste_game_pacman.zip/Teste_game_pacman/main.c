#include <string.h>
#include <ncurses.h>

#include "pacman.h"

int main() {
  initscr();
  curs_set(0);

  // testa se pode exibir outras cores no terminal
  if(has_colors() == FALSE){ 
    endwin();
    printf("Seu terminal não suporta cores.\n");
    return 1;
  }
  
  start_color();

  // tela: digite algo para iniciar
  print_title(LINES, COLS);

  getch();
  clear();

  // iniciar a tela do jogo
  pacman_game(LINES, COLS);

  endwin();
  return 0;
}